class Vehicle {
    constructor(make, model, year, ownerName){
    this.make=make;
    this.model=model;
    this.year=year;
    this.ownerName=ownerName;
    }

    displayDetails(){
        console.log(`Make: ${this.make}`);
        console.log(`Model: ${this.model}`);
        console.log(`Year: ${this.year}`);
        console.log(`OwnerName: ${this.ownerName}`);
    }
}

class Car extends Vehicle {
    constructor(make, model, year,ownerName, doors){
        super(make, model, year, ownerName);
        this.doors=doors;
    }
    displayDetails(){
        super.displayDetails();
        console.log(`Doors: ${this.doors}`);
    }
}

const vehicle = new Vehicle('Ford', 'F-150', 2020, 'Eugene Servito');

console.log('Vehicle Details:');
vehicle.displayDetails();

const car =new Car('Honda', 'Accord', 2023, 'Eugene Servito', 4);

console.log('\nVehicle Details:');
car.displayDetails();