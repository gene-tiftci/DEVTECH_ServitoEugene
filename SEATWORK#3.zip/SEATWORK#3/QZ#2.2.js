var num1=49;
var num2=100;
if (num1 > num2){
    console.log("It is greater");
} else {
    console.log("It is less than");
}

