var num=3;
if (num % 2 === 0){
    console.log("It is even number");
} else {
    console.log("It is odd number");
}
