var num=-10;
if (num > 0){
    console.log("It is possitive");
} else {
    console.log("It is negative");
}

